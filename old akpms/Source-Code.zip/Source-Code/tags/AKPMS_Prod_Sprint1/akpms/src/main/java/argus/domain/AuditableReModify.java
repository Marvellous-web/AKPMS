/**
 * 
 */
package argus.domain;

/**
 * @author jasdeep.s
 *
 */
public interface AuditableReModify extends AuditableCreateOnly, AuditableModifyOnly, AuditableReModifyOnly {

}
