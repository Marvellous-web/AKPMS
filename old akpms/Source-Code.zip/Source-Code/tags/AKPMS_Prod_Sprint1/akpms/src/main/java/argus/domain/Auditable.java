/**
 * 
 */
package argus.domain;

/**
 * @author bhupender.s
 *
 */
public interface Auditable extends AuditableModifyOnly,AuditableCreateOnly {

}
